import socket
import os

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
result = sock.connect_ex(('localhost', 5432))

if result == 0:
   os.system('sudo service postgresql stop')
   print('PostgreSQL is stopped')
else:
   os.system('sudo service postgresql start')
   print('PostgreSQL is started')
sock.close()