import os
import time
import requests
from PIL import Image
import numpy as np

data = os.listdir('test_img')

def read_img(path):
    img = Image.open(path).convert('L')
    img = np.array(img, dtype=np.float32)
    return img

with open("history.csv", 'w') as f_target:
    for row in data:

        features = read_img('test_img/'+row)

        t = time.localtime()
        current_time = time.strftime("%H:%M:%S", t)

        url = "http://localhost:9696/predict"
        response = requests.post(url, data=str(features.ravel().tolist()) + '_' + current_time).json()
        print(f"Result: {response}")
        f_target.write(f"{row}, {current_time}, {response}\n")

        time.sleep(1)