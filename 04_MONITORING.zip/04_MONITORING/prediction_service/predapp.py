import pickle
from flask import Flask, request, jsonify
import numpy as np
from flask_sqlalchemy import SQLAlchemy
import psycopg2
import os


with open('svm.b', 'rb') as f_in:
    model = pickle.load(f_in)

def predict(features):
    result = model.predict(features)
    return int(result[0])


def save_to_dtb(content):
    # Connect to your PostgreSQL database on a remote server
    conn = psycopg2.connect(host="0.0.0.0", port="5432", dbname="digit", user="postgres", password="03112001")
    # Open a cursor to perform database operations
    cur = conn.cursor()
    cur.execute(f"INSERT INTO pred_result (time, result) VALUES ('{content[0]}', {content[1]})")

    conn.commit()
    print(f"Saved {content}")

    # cur.execute("SELECT * FROM clients")
    # records = cur.fetchall()
    # print(records)

    cur.close()
    conn.close()
    #print("PostgreSQL connection is closed")

app = Flask('DIGIT_PREDICTION')

@app.route('/predict', methods=['POST'])
def predict_endpoint():
    data = request.get_data(as_text=True)
    data = data.split('_')
    features, time = data[0], data[1]
    features = np.fromstring(features[1:-1], dtype=np.float32, sep=',').reshape(1, -1)
    pred = predict(features)

    save_to_dtb([time, pred])

    return jsonify(pred)


if __name__ == "__main__": 
    app.run(debug=True, host='0.0.0.0', port=9696)